/**
 * Montfort High School - Admin Dashboard Controls
 */

document.addEventListener('DOMContentLoaded', function () {
  // Helper to compress images in-browser before converting to base64
  function compressImage(file, callback) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = new Image();
      img.onload = function () {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const MAX_WIDTH = 1200;
        const MAX_HEIGHT = 1200;
        
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        callback(dataUrl);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  const loginOverlay = document.getElementById('login-overlay');
  const adminPanel = document.getElementById('admin-panel');
  const loginForm = document.getElementById('admin-login-form');
  const userInput = document.getElementById('admin-user');
  const passwordInput = document.getElementById('admin-pass');
  const errorMsg = document.getElementById('login-error');

  // --- 1. Authentication Check ---
  function checkAuth() {
    if (sessionStorage.getItem('admin_logged') === 'true') {
      loginOverlay.style.display = 'none';
      adminPanel.style.display = 'grid';
      initDashboard();
    } else {
      loginOverlay.style.display = 'flex';
      adminPanel.style.display = 'none';
    }
  }

  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const username = userInput ? userInput.value : '';
      const password = passwordInput.value;
      if (username === 'adminmontfort' && password === 'Montfort@school2026') {
        sessionStorage.setItem('admin_logged', 'true');
        errorMsg.style.display = 'none';
        if (userInput) userInput.value = '';
        passwordInput.value = '';
        checkAuth();
      } else {
        errorMsg.style.display = 'block';
        passwordInput.value = '';
        if (userInput) userInput.focus();
      }
    });
  }

  const logoutBtn = document.getElementById('btn-admin-logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function () {
      sessionStorage.removeItem('admin_logged');
      checkAuth();
    });
  }

  // Initial authentication check (moved to bottom of DOMContentLoaded)

  // --- 2. Tab Navigation ---
  const navButtons = document.querySelectorAll('.admin-nav button');
  const sections = document.querySelectorAll('.admin-main .admin-section');

  navButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      navButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const targetId = btn.getAttribute('data-target');
      sections.forEach(sec => {
        if (sec.id === targetId) {
          sec.classList.add('active');
        } else {
          sec.classList.remove('active');
        }
      });
    });
  });

  // --- 3. Dashboard Logic ---
  function initDashboard() {
    if (!window.SchoolStore) return;

    // Load static values
    loadHeroSettings();
    loadThemeSettings();
    loadPrincipalSettings();

    // Load active arrays
    renderNewsTable();
    renderGalleryTable();
    renderAchievementsTable();
    renderEnquiriesTable();
    renderSlideshowTable();
    renderFacilitiesTable();
    renderEventsTable();
  }

  // Reset DB to defaults
  const resetBtn = document.getElementById('btn-reset-db');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      if (confirm('Are you sure you want to reset all modifications to default settings? All custom announcements, gallery uploads, and enquiry list submissions will be overwritten.')) {
        window.SchoolStore.resetToDefaults();
        alert('Database has been reset to defaults.');
        window.location.reload();
      }
    });
  }

  // 3.1 Hero Settings Tab
  const heroForm = document.getElementById('admin-hero-form');
  const heroTitleInput = document.getElementById('hero-title-input');
  const heroSubtitleInput = document.getElementById('hero-subtitle-input');
  const heroTaglineInput = document.getElementById('hero-tagline-input');
  const heroEstInput = document.getElementById('hero-stat-established');
  const heroStudentsInput = document.getElementById('hero-stat-students');
  const heroStaffInput = document.getElementById('hero-stat-staff');
  const heroExcellenceInput = document.getElementById('hero-stat-excellence');
  const heroImageInput = document.getElementById('hero-image-input');
  const heroImagePreview = document.getElementById('hero-image-preview');

  function loadHeroSettings() {
    const hero = window.SchoolStore.getHero();
    if (hero) {
      heroTitleInput.value = hero.title;
      heroSubtitleInput.value = hero.subtitle;
      heroTaglineInput.value = hero.tagline;
      heroEstInput.value = hero.stats.established;
      heroStudentsInput.value = hero.stats.students;
      heroStaffInput.value = hero.stats.staff;
      heroExcellenceInput.value = hero.stats.excellence;
      heroImageInput.value = hero.backgroundImage;
      heroImagePreview.src = hero.backgroundImage;
    }
  }

  // Update Hero Preview live
  if (heroImageInput) {
    heroImageInput.addEventListener('input', function () {
      heroImagePreview.src = heroImageInput.value;
    });
  }

  if (heroForm) {
    heroForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const updatedHero = {
        title: heroTitleInput.value,
        subtitle: heroSubtitleInput.value,
        tagline: heroTaglineInput.value,
        backgroundImage: heroImageInput.value,
        stats: {
          established: heroEstInput.value,
          students: heroStudentsInput.value,
          staff: heroStaffInput.value,
          excellence: heroExcellenceInput.value
        }
      };

      window.SchoolStore.updateHero(updatedHero);
      alert('Hero settings saved successfully!');
    });
  }

  // Theme of the Year Banner Settings
  const themeForm = document.getElementById('admin-theme-form');
  const themeKeywordInput = document.getElementById('theme-keyword-input');
  const themeDescInput = document.getElementById('theme-desc-input');

  function loadThemeSettings() {
    const theme = window.SchoolStore.getTheme();
    if (theme) {
      themeKeywordInput.value = theme.keyword;
      themeDescInput.value = theme.description;
    }
  }

  if (themeForm) {
    themeForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.SchoolStore.updateTheme({
        keyword: themeKeywordInput.value,
        description: themeDescInput.value
      });
      alert('Theme banner updated successfully!');
    });
  }

  // Principal Settings
  const principalForm = document.getElementById('admin-principal-form');
  const principalNameInput = document.getElementById('principal-name-input');
  const principalTextInput = document.getElementById('principal-text-input');
  const principalImageInput = document.getElementById('principal-image-input');
  const principalMessageInput = document.getElementById('principal-message-input');

  function loadPrincipalSettings() {
    const principal = window.SchoolStore.getPrincipalDesk();
    if (principal) {
      principalNameInput.value = principal.fullName;
      principalTextInput.value = principal.text;
      principalImageInput.value = principal.image;
      principalMessageInput.value = principal.message;
    }
  }

  if (principalForm) {
    principalForm.addEventListener('submit', function (e) {
      e.preventDefault();
      window.SchoolStore.updatePrincipalDesk({
        fullName: principalNameInput.value,
        text: principalTextInput.value,
        image: principalImageInput.value,
        message: principalMessageInput.value
      });
      alert('Principal desk settings saved successfully!');
    });
  }

  // 3.2 Announcements tab (News)
  const newsForm = document.getElementById('admin-news-form');
  const newsTitleInput = document.getElementById('news-title-input');
  const newsBadgeInput = document.getElementById('news-badge-input');
  const newsLinkInput = document.getElementById('news-link-input');
  const newsTbody = document.getElementById('admin-news-tbody');

  let editingNewsId = null;

  const newsCancelBtn = document.getElementById('news-cancel-btn');
  const newsSubmitBtn = document.getElementById('news-submit-btn');
  const newsFormTitle = document.getElementById('news-form-title');

  function resetNewsForm() {
    newsTitleInput.value = '';
    newsBadgeInput.value = '';
    if (newsLinkInput) newsLinkInput.value = '';
    editingNewsId = null;
    if (newsFormTitle) newsFormTitle.textContent = 'Add New Announcement';
    if (newsSubmitBtn) newsSubmitBtn.textContent = 'Publish Announcement';
    if (newsCancelBtn) newsCancelBtn.style.display = 'none';
  }

  if (newsCancelBtn) {
    newsCancelBtn.addEventListener('click', resetNewsForm);
  }

  function renderNewsTable() {
    if (!newsTbody) return;
    const news = window.SchoolStore.getNews();
    newsTbody.innerHTML = '';
    
    if (news.length === 0) {
      newsTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--text-light);">No active announcements.</td></tr>';
      return;
    }

    news.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight: 600;">${item.title}</td>
        <td>${item.badge ? `<span class="news-badge" style="margin-left: 0;">${item.badge}</span>` : '<span style="color: #94a3b8;">None</span>'}</td>
        <td>${item.date}</td>
        <td>
          <button class="btn-success edit-news-btn" data-id="${item.id}" style="margin-right: 5px;">Edit</button>
          <button class="btn-danger delete-news-btn" data-id="${item.id}">Delete</button>
        </td>
      `;
      newsTbody.appendChild(tr);
    });

    // Attach click events to edit buttons
    const editBtns = newsTbody.querySelectorAll('.edit-news-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const newsId = btn.getAttribute('data-id');
        const item = news.find(n => n.id === parseInt(newsId));
        if (item) {
          editingNewsId = newsId;
          newsTitleInput.value = item.title;
          newsBadgeInput.value = item.badge || '';
          if (newsLinkInput) newsLinkInput.value = item.link || '';
          if (newsFormTitle) newsFormTitle.textContent = `Edit Announcement: ${item.title}`;
          if (newsSubmitBtn) newsSubmitBtn.textContent = 'Save Changes';
          if (newsCancelBtn) newsCancelBtn.style.display = 'inline-block';
          document.getElementById('admin-news-form').scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    // Attach click events to delete buttons
    const deleteBtns = newsTbody.querySelectorAll('.delete-news-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const newsId = btn.getAttribute('data-id');
        if (confirm('Delete this announcement?')) {
          window.SchoolStore.deleteNews(newsId);
          renderNewsTable();
        }
      });
    });
  }

  if (newsForm) {
    newsForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const title = newsTitleInput.value;
      const badge = newsBadgeInput.value;
      const link = newsLinkInput ? newsLinkInput.value : '';
      
      if (editingNewsId) {
        window.SchoolStore.updateNews(editingNewsId, title, badge, link);
        alert('Announcement updated successfully!');
      } else {
        window.SchoolStore.addNews(title, badge, link);
        alert('Announcement published!');
      }
      
      resetNewsForm();
      renderNewsTable();
    });
  }

  // 3.3 Gallery Tab File Upload & conversion to Base64
  const galleryForm = document.getElementById('admin-gallery-form');
  const galTitleInput = document.getElementById('gal-title-input');
  const galCategoryInput = document.getElementById('gal-category-input');
  const galFileInput = document.getElementById('gal-file-input');
  const galFileName = document.getElementById('gal-file-name');
  const galImagePreview = document.getElementById('gal-image-preview');
  const galPlaceholder = document.getElementById('gal-preview-placeholder');
  const galleryTbody = document.getElementById('admin-gallery-tbody');
  
  let selectedFileBase64 = '';
  let editingGalleryId = null;

  const galCancelBtn = document.getElementById('gal-cancel-btn');
  const galSubmitBtn = document.getElementById('gal-submit-btn');
  const galFormTitle = document.getElementById('gal-form-title');

  function resetGalleryForm() {
    galTitleInput.value = '';
    galCategoryInput.value = '';
    galFileInput.value = '';
    galFileName.textContent = 'No file chosen';
    galImagePreview.style.display = 'none';
    galPlaceholder.style.display = 'block';
    selectedFileBase64 = '';
    editingGalleryId = null;
    if (galFormTitle) galFormTitle.textContent = 'Upload Photo to Gallery';
    if (galSubmitBtn) galSubmitBtn.textContent = 'Upload to Gallery';
    if (galCancelBtn) galCancelBtn.style.display = 'none';
  }

  if (galCancelBtn) {
    galCancelBtn.addEventListener('click', resetGalleryForm);
  }

  if (galFileInput) {
    galFileInput.addEventListener('change', function () {
      const file = galFileInput.files[0];
      if (file) {
        galFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          selectedFileBase64 = compressedBase64;
          galImagePreview.src = selectedFileBase64;
          galImagePreview.style.display = 'block';
          galPlaceholder.style.display = 'none';
          galFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        galFileName.textContent = 'No file chosen';
        selectedFileBase64 = '';
        if (!editingGalleryId) {
          galImagePreview.style.display = 'none';
          galPlaceholder.style.display = 'block';
        }
      }
    });
  }

  function renderGalleryTable() {
    if (!galleryTbody) return;
    const photos = window.SchoolStore.getGallery();
    galleryTbody.innerHTML = '';

    if (photos.length === 0) {
      galleryTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--text-light);">No images in gallery.</td></tr>';
      return;
    }

    photos.forEach(photo => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div class="img-preview-box" style="width: 80px; height: 50px; margin-top: 0;">
            <img src="${photo.image}" alt="Thumb">
          </div>
        </td>
        <td style="font-weight: 600;">${photo.title}</td>
        <td style="text-transform: capitalize;">${photo.category}</td>
        <td>
          <button class="btn-success edit-gal-btn" data-id="${photo.id}" style="margin-right: 5px;">Edit</button>
          <button class="btn-danger delete-gal-btn" data-id="${photo.id}">Delete</button>
        </td>
      `;
      galleryTbody.appendChild(tr);
    });

    const editBtns = galleryTbody.querySelectorAll('.edit-gal-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const photoId = btn.getAttribute('data-id');
        const photo = photos.find(p => p.id === parseInt(photoId));
        if (photo) {
          editingGalleryId = photoId;
          galTitleInput.value = photo.title;
          galCategoryInput.value = photo.category;
          galImagePreview.src = photo.image;
          galImagePreview.style.display = 'block';
          galPlaceholder.style.display = 'none';
          if (galFormTitle) galFormTitle.textContent = `Edit Photo: ${photo.title}`;
          if (galSubmitBtn) galSubmitBtn.textContent = 'Save Changes';
          if (galCancelBtn) galCancelBtn.style.display = 'inline-block';
          document.getElementById('admin-gallery-form').scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    const deleteBtns = galleryTbody.querySelectorAll('.delete-gal-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const photoId = btn.getAttribute('data-id');
        if (confirm('Delete this photo from the gallery?')) {
          window.SchoolStore.deleteGalleryImage(photoId);
          renderGalleryTable();
        }
      });
    });
  }

  if (galleryForm) {
    galleryForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const title = galTitleInput.value;
      const category = galCategoryInput.value;

      if (editingGalleryId) {
        window.SchoolStore.updateGalleryImage(editingGalleryId, title, category, selectedFileBase64 || null);
        alert('Photo details updated successfully!');
      } else {
        if (!selectedFileBase64) {
          alert('Please select an image file first.');
          return;
        }
        window.SchoolStore.addGalleryImage(title, category, selectedFileBase64);
        alert('Photo uploaded to gallery successfully!');
      }
      
      resetGalleryForm();
      renderGalleryTable();
    });
  }

  // 3.4 Enquiries Tab
  const enquiriesTbody = document.getElementById('admin-enquiries-tbody');

  function renderEnquiriesTable() {
    if (!enquiriesTbody) return;
    const enquiries = window.SchoolStore.getEnquiries();
    enquiriesTbody.innerHTML = '';

    if (enquiries.length === 0) {
      enquiriesTbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-light);">No enquiry submissions found.</td></tr>';
      return;
    }

    enquiries.forEach(item => {
      const dateFormatted = new Date(item.date).toLocaleString();
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-size: 0.8rem; color: var(--text-light);">${dateFormatted}</td>
        <td>
          <div style="font-weight: 700; color: var(--primary-navy);">${item.name}</div>
          <div style="font-size: 0.8rem;">📧 ${item.email}</div>
          <div style="font-size: 0.8rem;">📞 ${item.phone}</div>
          <div style="font-size: 0.75rem; color: var(--text-light);">State: ${item.state}</div>
        </td>
        <td>
          <div style="font-weight: 600; font-size: 0.85rem;">Class: ${item.currentClass}</div>
          <div style="font-size: 0.8rem; color: var(--text-light);">Syllabus: ${item.syllabus}</div>
          <div style="font-size: 0.8rem; color: var(--text-light);">Campus: ${item.campus}</div>
          <div style="font-size: 0.8rem; color: var(--text-light);">Prog: ${item.programme}</div>
        </td>
        <td style="font-size: 0.85rem; max-width: 300px; word-break: break-word;">${item.message || '<span style="color: #94a3b8; font-style: italic;">No message</span>'}</td>
        <td>
          <button class="btn-danger delete-enq-btn" data-id="${item.id}">Delete</button>
        </td>
      `;
      enquiriesTbody.appendChild(tr);
    });

    const deleteBtns = enquiriesTbody.querySelectorAll('.delete-enq-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const enqId = btn.getAttribute('data-id');
        if (confirm('Delete this enquiry?')) {
          window.SchoolStore.deleteEnquiry(enqId);
          renderEnquiriesTable();
        }
      });
    });
  }

  // 3.5 Achievements Tab CRUD and Image uploading
  const achievementsForm = document.getElementById('admin-achievements-form');
  const achTitleInput = document.getElementById('ach-title-input');
  const achCategoryInput = document.getElementById('ach-category-input');
  const achFileInput = document.getElementById('ach-file-input');
  const achFileName = document.getElementById('ach-file-name');
  const achImagePreview = document.getElementById('ach-image-preview');
  const achPlaceholder = document.getElementById('ach-preview-placeholder');
  const achievementsTbody = document.getElementById('admin-achievements-tbody');

  let achSelectedFileBase64 = '';
  let editingAchievementId = null;

  const achCancelBtn = document.getElementById('ach-cancel-btn');
  const achSubmitBtn = document.getElementById('ach-submit-btn');
  const achFormTitle = document.getElementById('ach-form-title');

  function resetAchievementsForm() {
    achTitleInput.value = '';
    achCategoryInput.value = '';
    achFileInput.value = '';
    achFileName.textContent = 'No file chosen';
    achImagePreview.style.display = 'none';
    achPlaceholder.style.display = 'block';
    achSelectedFileBase64 = '';
    editingAchievementId = null;
    if (achFormTitle) achFormTitle.textContent = 'Add Achievement Image';
    if (achSubmitBtn) achSubmitBtn.textContent = 'Add Achievement Image';
    if (achCancelBtn) achCancelBtn.style.display = 'none';
  }

  if (achCancelBtn) {
    achCancelBtn.addEventListener('click', resetAchievementsForm);
  }

  if (achFileInput) {
    achFileInput.addEventListener('change', function () {
      const file = achFileInput.files[0];
      if (file) {
        achFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          achSelectedFileBase64 = compressedBase64;
          achImagePreview.src = achSelectedFileBase64;
          achImagePreview.style.display = 'block';
          achPlaceholder.style.display = 'none';
          achFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        achFileName.textContent = 'No file chosen';
        achSelectedFileBase64 = '';
        if (!editingAchievementId) {
          achImagePreview.style.display = 'none';
          achPlaceholder.style.display = 'block';
        }
      }
    });
  }

  function renderAchievementsTable() {
    if (!achievementsTbody) return;
    const achievements = window.SchoolStore.getAchievements();
    achievementsTbody.innerHTML = '';

    if (achievements.length === 0) {
      achievementsTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--text-light);">No achievements loaded.</td></tr>';
      return;
    }

    achievements.forEach(item => {
      const tr = document.createElement('tr');
      
      let catLabel = item.category;
      if (item.category === 'boards') catLabel = 'SSC 10th Boards';
      else if (item.category === 'prathiba') catLabel = 'Prathiba Awards';
      else if (item.category === 'competitive') catLabel = 'JEE & NEET';

      tr.innerHTML = `
        <td>
          <div class="img-preview-box" style="width: 80px; height: 50px; margin-top: 0;">
            <img src="${item.image}" alt="Thumb">
          </div>
        </td>
        <td style="font-weight: 600;">${item.title || 'Untitled'}</td>
        <td style="text-transform: capitalize;">${catLabel}</td>
        <td>
          <button class="btn-success edit-ach-btn" data-id="${item.id}" style="margin-right: 5px;">Edit</button>
          <button class="btn-danger delete-ach-btn" data-id="${item.id}">Delete</button>
        </td>
      `;
      achievementsTbody.appendChild(tr);
    });

    const editBtns = achievementsTbody.querySelectorAll('.edit-ach-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const achId = btn.getAttribute('data-id');
        const ach = achievements.find(a => a.id === parseInt(achId));
        if (ach) {
          editingAchievementId = achId;
          achTitleInput.value = ach.title || '';
          achCategoryInput.value = ach.category;
          achImagePreview.src = ach.image;
          achImagePreview.style.display = 'block';
          achPlaceholder.style.display = 'none';
          if (achFormTitle) achFormTitle.textContent = `Edit Achievement: ${ach.title || 'Untitled'}`;
          if (achSubmitBtn) achSubmitBtn.textContent = 'Save Changes';
          if (achCancelBtn) achCancelBtn.style.display = 'inline-block';
          document.getElementById('admin-achievements-form').scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    const deleteBtns = achievementsTbody.querySelectorAll('.delete-ach-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const achId = btn.getAttribute('data-id');
        if (confirm('Delete this achievement image?')) {
          window.SchoolStore.deleteAchievement(achId);
          renderAchievementsTable();
        }
      });
    });
  }

  if (achievementsForm) {
    achievementsForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const title = achTitleInput.value;
      const category = achCategoryInput.value;

      if (editingAchievementId) {
        window.SchoolStore.updateAchievement(editingAchievementId, title, category, achSelectedFileBase64 || null);
        alert('Achievement image updated successfully!');
      } else {
        if (!achSelectedFileBase64) {
          alert('Please select an image file first.');
          return;
        }
        window.SchoolStore.addAchievement(title, category, achSelectedFileBase64);
        alert('Achievement image uploaded successfully!');
      }

      resetAchievementsForm();
      renderAchievementsTable();
    });
  }

  // --- 3.6 Slideshow Background Images Manager ---
  const slideshowForm = document.getElementById('admin-slideshow-form');
  const slideFileInput = document.getElementById('slide-file-input');
  const slideFileName = document.getElementById('slide-file-name');
  const slideshowTbody = document.getElementById('admin-slideshow-tbody');
  let selectedSlideBase64 = '';

  if (slideFileInput) {
    slideFileInput.addEventListener('change', function () {
      const file = slideFileInput.files[0];
      if (file) {
        slideFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          selectedSlideBase64 = compressedBase64;
          slideFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        slideFileName.textContent = 'No file chosen';
        selectedSlideBase64 = '';
      }
    });
  }

  function renderSlideshowTable() {
    if (!slideshowTbody) return;
    const hero = window.SchoolStore.getHero();
    const slides = hero.backgroundImages || [];
    slideshowTbody.innerHTML = '';

    if (slides.length === 0) {
      slideshowTbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--text-light);">No custom backgrounds. Using hero default.</td></tr>';
      return;
    }

    slides.forEach((slideUrl, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div class="img-preview-box" style="width: 80px; height: 50px; margin-top: 0;">
            <img src="${slideUrl}" alt="Slide">
          </div>
        </td>
        <td style="font-size: 0.8rem; word-break: break-all; max-width: 300px;">${slideUrl.substring(0, 100)}${slideUrl.length > 100 ? '...' : ''}</td>
        <td>
          <button class="btn-danger delete-slide-btn" data-index="${idx}">Delete</button>
        </td>
      `;
      slideshowTbody.appendChild(tr);
    });

    const deleteBtns = slideshowTbody.querySelectorAll('.delete-slide-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const index = parseInt(btn.getAttribute('data-index'));
        if (confirm('Delete this background from slider?')) {
          const hero = window.SchoolStore.getHero();
          const slides = hero.backgroundImages || [];
          slides.splice(index, 1);
          window.SchoolStore.updateHero({ backgroundImages: slides });
          renderSlideshowTable();
        }
      });
    });
  }

  if (slideshowForm) {
    slideshowForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!selectedSlideBase64) {
        alert('Please choose an image file first.');
        return;
      }
      const hero = window.SchoolStore.getHero();
      const slides = hero.backgroundImages || [];
      slides.push(selectedSlideBase64);
      window.SchoolStore.updateHero({ backgroundImages: slides });
      alert('Background image added to slideshow!');
      slideFileInput.value = '';
      slideFileName.textContent = 'No file chosen';
      selectedSlideBase64 = '';
      renderSlideshowTable();
    });
  }

  // --- 3.7 Page Banners & Static Photos Settings Form ---
  const pageImgForm = document.getElementById('admin-page-settings-form');
  const pageImgSelect = document.getElementById('page-image-select');
  const pageImgFileInput = document.getElementById('page-img-file-input');
  const pageImgFileName = document.getElementById('page-img-file-name');
  const pageImgPreview = document.getElementById('page-img-preview');
  const pageImgPlaceholder = document.getElementById('page-img-placeholder');
  let selectedPageImgBase64 = '';

  if (pageImgSelect) {
    pageImgSelect.addEventListener('change', function () {
      const key = pageImgSelect.value;
      const settings = window.SchoolStore.getPageSettings();
      if (settings && settings[key]) {
        pageImgPreview.src = settings[key];
        pageImgPreview.style.display = 'block';
        pageImgPlaceholder.style.display = 'none';
      } else {
        pageImgPreview.style.display = 'none';
        pageImgPlaceholder.style.display = 'block';
      }
    });
  }

  if (pageImgFileInput) {
    pageImgFileInput.addEventListener('change', function () {
      const file = pageImgFileInput.files[0];
      if (file) {
        pageImgFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          selectedPageImgBase64 = compressedBase64;
          pageImgPreview.src = selectedPageImgBase64;
          pageImgPreview.style.display = 'block';
          pageImgPlaceholder.style.display = 'none';
          pageImgFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        pageImgFileName.textContent = 'No file chosen';
        selectedPageImgBase64 = '';
      }
    });
  }

  if (pageImgForm) {
    pageImgForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const key = pageImgSelect.value;
      if (!key) {
        alert('Please select a target photo/banner first.');
        return;
      }
      if (!selectedPageImgBase64) {
        alert('Please choose a replacement image first.');
        return;
      }
      window.SchoolStore.updatePageSetting(key, selectedPageImgBase64);
      alert('Page banner / photo updated successfully!');
      pageImgFileInput.value = '';
      pageImgFileName.textContent = 'No file chosen';
      selectedPageImgBase64 = '';
    });
  }

  // --- 3.8 Facilities Manager ---
  const facForm = document.getElementById('admin-facility-form');
  const facTitleInput = document.getElementById('fac-title-input');
  const facDescInput = document.getElementById('fac-desc-input');
  const facFileInput = document.getElementById('fac-file-input');
  const facFileName = document.getElementById('fac-file-name');
  const facImagePreview = document.getElementById('fac-image-preview');
  const facPlaceholder = document.getElementById('fac-preview-placeholder');
  const facilitiesTbody = document.getElementById('admin-facilities-tbody');

  let selectedFacBase64 = '';
  let editingFacilityId = null;

  const facCancelBtn = document.getElementById('fac-cancel-btn');
  const facSubmitBtn = document.getElementById('fac-submit-btn');
  const facFormTitle = document.getElementById('fac-form-title');

  function resetFacilitiesForm() {
    facTitleInput.value = '';
    facDescInput.value = '';
    facFileInput.value = '';
    facFileName.textContent = 'No file chosen';
    facImagePreview.style.display = 'none';
    facPlaceholder.style.display = 'block';
    selectedFacBase64 = '';
    editingFacilityId = null;
    if (facFormTitle) facFormTitle.textContent = 'Add New Facility';
    if (facSubmitBtn) facSubmitBtn.textContent = 'Add Facility';
    if (facCancelBtn) facCancelBtn.style.display = 'none';
  }

  if (facCancelBtn) {
    facCancelBtn.addEventListener('click', resetFacilitiesForm);
  }

  if (facFileInput) {
    facFileInput.addEventListener('change', function () {
      const file = facFileInput.files[0];
      if (file) {
        facFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          selectedFacBase64 = compressedBase64;
          facImagePreview.src = selectedFacBase64;
          facImagePreview.style.display = 'block';
          facPlaceholder.style.display = 'none';
          facFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        facFileName.textContent = 'No file chosen';
        selectedFacBase64 = '';
        if (!editingFacilityId) {
          facImagePreview.style.display = 'none';
          facPlaceholder.style.display = 'block';
        }
      }
    });
  }

  function renderFacilitiesTable() {
    if (!facilitiesTbody) return;
    const facilities = window.SchoolStore.getFacilities();
    facilitiesTbody.innerHTML = '';

    if (facilities.length === 0) {
      facilitiesTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--text-light);">No active facilities.</td></tr>';
      return;
    }

    facilities.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div class="img-preview-box" style="width: 80px; height: 50px; margin-top: 0;">
            <img src="${item.image}" alt="Thumb">
          </div>
        </td>
        <td style="font-weight: 600;">${item.title}</td>
        <td style="font-size: 0.85rem; max-width: 300px; word-break: break-word;">${item.description}</td>
        <td>
          <button class="btn-success edit-fac-btn" data-id="${item.id}" style="margin-right: 5px;">Edit</button>
          <button class="btn-danger delete-fac-btn" data-id="${item.id}">Delete</button>
        </td>
      `;
      facilitiesTbody.appendChild(tr);
    });

    const editBtns = facilitiesTbody.querySelectorAll('.edit-fac-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const facId = btn.getAttribute('data-id');
        const fac = facilities.find(f => f.id === parseInt(facId));
        if (fac) {
          editingFacilityId = facId;
          facTitleInput.value = fac.title;
          facDescInput.value = fac.description;
          facImagePreview.src = fac.image;
          facImagePreview.style.display = 'block';
          facPlaceholder.style.display = 'none';
          if (facFormTitle) facFormTitle.textContent = `Edit Facility: ${fac.title}`;
          if (facSubmitBtn) facSubmitBtn.textContent = 'Save Changes';
          if (facCancelBtn) facCancelBtn.style.display = 'inline-block';
          document.getElementById('admin-facility-form').scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    const deleteBtns = facilitiesTbody.querySelectorAll('.delete-fac-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const facId = btn.getAttribute('data-id');
        if (confirm('Delete this facility?')) {
          window.SchoolStore.deleteFacility(facId);
          renderFacilitiesTable();
        }
      });
    });
  }

  if (facForm) {
    facForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const title = facTitleInput.value;
      const desc = facDescInput.value;

      if (editingFacilityId) {
        window.SchoolStore.updateFacility(editingFacilityId, title, desc, selectedFacBase64 || null);
        alert('Facility updated successfully!');
      } else {
        if (!selectedFacBase64) {
          alert('Please choose an image file first.');
          return;
        }
        window.SchoolStore.addFacility(title, desc, selectedFacBase64);
        alert('Facility added successfully!');
      }
      
      resetFacilitiesForm();
      renderFacilitiesTable();
    });
  }

  // --- 3.9 Recent Events Manager ---
  const evForm = document.getElementById('admin-event-form');
  const evTitleInput = document.getElementById('ev-title-input');
  const evFileInput = document.getElementById('ev-file-input');
  const evFileName = document.getElementById('ev-file-name');
  const evImagePreview = document.getElementById('ev-image-preview');
  const evPlaceholder = document.getElementById('ev-preview-placeholder');
  const eventsTbody = document.getElementById('admin-events-tbody');

  let selectedEvBase64 = '';
  let editingEventId = null;

  const evCancelBtn = document.getElementById('ev-cancel-btn');
  const evSubmitBtn = document.getElementById('ev-submit-btn');
  const evFormTitle = document.getElementById('ev-form-title');

  function resetEventsForm() {
    evTitleInput.value = '';
    evFileInput.value = '';
    evFileName.textContent = 'No file chosen';
    evImagePreview.style.display = 'none';
    evPlaceholder.style.display = 'block';
    selectedEvBase64 = '';
    editingEventId = null;
    if (evFormTitle) evFormTitle.textContent = 'Add Recent Event';
    if (evSubmitBtn) evSubmitBtn.textContent = 'Add Recent Event';
    if (evCancelBtn) evCancelBtn.style.display = 'none';
  }

  if (evCancelBtn) {
    evCancelBtn.addEventListener('click', resetEventsForm);
  }

  if (evFileInput) {
    evFileInput.addEventListener('change', function () {
      const file = evFileInput.files[0];
      if (file) {
        evFileName.textContent = file.name + ' (Compressing...)';
        compressImage(file, function (compressedBase64) {
          selectedEvBase64 = compressedBase64;
          evImagePreview.src = selectedEvBase64;
          evImagePreview.style.display = 'block';
          evPlaceholder.style.display = 'none';
          evFileName.textContent = file.name + ' (Ready)';
        });
      } else {
        evFileName.textContent = 'No file chosen';
        selectedEvBase64 = '';
        if (!editingEventId) {
          evImagePreview.style.display = 'none';
          evPlaceholder.style.display = 'block';
        }
      }
    });
  }

  function renderEventsTable() {
    if (!eventsTbody) return;
    const events = window.SchoolStore.getEvents();
    eventsTbody.innerHTML = '';

    if (events.length === 0) {
      eventsTbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--text-light);">No events listed.</td></tr>';
      return;
    }

    events.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div class="img-preview-box" style="width: 80px; height: 50px; margin-top: 0;">
            <img src="${item.image}" alt="Thumb">
          </div>
        </td>
        <td style="font-weight: 600;">${item.title}</td>
        <td>
          <button class="btn-success edit-ev-btn" data-id="${item.id}" style="margin-right: 5px;">Edit</button>
          <button class="btn-danger delete-ev-btn" data-id="${item.id}">Delete</button>
        </td>
      `;
      eventsTbody.appendChild(tr);
    });

    const editBtns = eventsTbody.querySelectorAll('.edit-ev-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const evId = btn.getAttribute('data-id');
        const ev = events.find(e => e.id === parseInt(evId));
        if (ev) {
          editingEventId = evId;
          evTitleInput.value = ev.title;
          evImagePreview.src = ev.image;
          evImagePreview.style.display = 'block';
          evPlaceholder.style.display = 'none';
          if (evFormTitle) evFormTitle.textContent = `Edit Event: ${ev.title}`;
          if (evSubmitBtn) evSubmitBtn.textContent = 'Save Changes';
          if (evCancelBtn) evCancelBtn.style.display = 'inline-block';
          document.getElementById('admin-event-form').scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    const deleteBtns = eventsTbody.querySelectorAll('.delete-ev-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        const evId = btn.getAttribute('data-id');
        if (confirm('Delete this event from the homepage?')) {
          window.SchoolStore.deleteEvent(evId);
          renderEventsTable();
        }
      });
    });
  }

  if (evForm) {
    evForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const title = evTitleInput.value;

      if (editingEventId) {
        window.SchoolStore.updateEvent(editingEventId, title, selectedEvBase64 || null);
        alert('Event updated successfully!');
      } else {
        if (!selectedEvBase64) {
          alert('Please choose an image file first.');
          return;
        }
        window.SchoolStore.addEvent(title, selectedEvBase64);
        alert('Event added successfully!');
      }
      
      resetEventsForm();
      renderEventsTable();
    });
  }

  // --- 3.10 Database Export & Import ---
  const exportBtn = document.getElementById('btn-export-db');
  const importFileInput = document.getElementById('import-db-file');

  if (exportBtn) {
    exportBtn.addEventListener('click', function () {
      const dbStr = window.SchoolStore.getRawDbString();
      const blob = new Blob([dbStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'montfort_school_db.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  if (importFileInput) {
    importFileInput.addEventListener('change', function () {
      const file = importFileInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
          const success = window.SchoolStore.importDb(e.target.result);
          if (success) {
            alert('Database imported successfully! Re-loading dashboard...');
            window.location.reload();
          } else {
            alert('Error: Invalid database backup file format.');
          }
        };
        reader.readAsText(file);
      }
    });
  }

  // Initial authentication check executed after all variables are declared
  checkAuth();
});
