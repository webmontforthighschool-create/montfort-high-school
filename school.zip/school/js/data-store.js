/**

 * Montfort High School - Data Store Layer

 * Implements client-side persistence using localStorage.

 */



(function () {

  const STORE_KEY = 'montfort_school_db';



  const defaultDb = {

    hero: {

      title: "Montfort High School, Repalle",

      subtitle: "Education with Love, to Create a Knowledge Powered Society, to Serve Humanity.",

      tagline: "\"Knowledge is Power\"",

      backgroundImage: "images/Graduation day/DSC_0190.JPG",

      backgroundImages: [

        "images/Graduation day/DSC_0190.JPG",

        "images/Sports Day/DSC_4794.JPG",

        "images/Academic Activities/Assemblies/DSCN4493.JPG",

        "images/Graduation day/DSC_0220.JPG"

      ],

      stats: {

        established: "2000",

        students: "1550+",

        staff: "60+",

        excellence: "26+"

      }

    },

    theme: {

      title: "THEME OF THE YEAR",

      keyword: "LEADERSHIP",

      description: "Developing responsible leaders for tomorrow."

    },

    principalDesk: {

      title: "Welcome to Montfort High School",

      subtitle: "PRINCIPAL'S DESK",

      text: "Welcome to Montfort High School, Repalle. Since 2000, our institution has been committed to providing quality education with love, discipline, and values. We strive to nurture every child into a confident, responsible, and knowledgeable citizen.",

      image: "images/principal.jpg",

      fullName: "Br. Kiran Kumar",

      designation: "PRINCIPAL, MONTFORT HIGH SCHOOL",

      message: "Wishing you all the best. A school is more than just an infrastructure; it is a space where young minds are nurtured, dreams take flight, and futures are built. At Montfort, our endeavor has always been to impart education that builds character and confidence."

    },

    news: [

      { id: 1, title: "Admissions Open 2026-2027", badge: "New", date: "2026-07-01" },

      { id: 2, title: "Examination Schedule Released", badge: "", date: "2026-06-28" },

      { id: 3, title: "Annual Day Celebrations", badge: "", date: "2026-06-15" },

      { id: 4, title: "Olympiad Registration Info", badge: "", date: "2026-06-10" },

      { id: 5, title: "Holiday Notice Update", badge: "", date: "2026-06-05" }

    ],

    gallery: [

      { id: 1, title: "Republic Day Parade", category: "celebrations", image: "images/Republic Day/DSC_6584.JPG" },

      { id: 2, title: "Pongal & Rangoli Festival", category: "celebrations", image: "images/Pongal & Rangoli/DSC_652.jpeg" },

      { id: 3, title: "Montfort Birthday Celebration", category: "celebrations", image: "images/Montfort B-day/DSC_7008.JPG" },

      { id: 4, title: "Independence Day Festivities", category: "celebrations", image: "images/Montfort B-day/DSC_7211.JPG" },

      { id: 5, title: "Free Medical Camp", category: "social_responsibility", image: "images/Medical Camp/DSCN0305.JPG" },

      { id: 6, title: "Grocery Distribution for Charity", category: "social_responsibility", image: "images/Social Service/Distributing Groceries to PH/DSC_3439.JPG" },

      { id: 7, title: "Flood Relief Camp", category: "social_responsibility", image: "images/Social Service/Flood Victims/DSC_6890.JPG" },

      { id: 8, title: "Food Fest for Charity", category: "social_responsibility", image: "images/Social Service/Food Fest/DSC_3199.JPG" },

      { id: 9, title: "Sports Day Ceremonies", category: "sports", image: "images/Sports Day/DSC_4794.JPG" },

      { id: 10, title: "Football and Games Practice", category: "sports", image: "images/Sports and Games/DSCN1082.JPG" },

      { id: 11, title: "KG Playing Zone", category: "sports", image: "images/Sports and Games/KG Playing Equipment/DSC_8538.JPG" },

      { id: 12, title: "SSC Results Toppers Board 1", category: "achievements", image: "images/SSC Results 2026/9x6=1c (SSC-2026)_1(RV).jpg" },

      { id: 13, title: "SSC Results Toppers Board 2", category: "achievements", image: "images/SSC Results 2026/9x6=1c (SSC-2026)_2.jpg" },

      { id: 14, title: "Prathiba Award Winners 1", category: "achievements", image: "images/Prathiba award/DSC_6945.JPG" },

      { id: 15, title: "Prathiba Award Winners 2", category: "achievements", image: "images/Prathiba award/DSC_6946.JPG" },

      { id: 16, title: "Prathiba Award Winners 3", category: "achievements", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.55.16 PM.jpeg" },

      { id: 17, title: "Prathiba Award Winners 4", category: "achievements", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.55.54 PM.jpeg" },

      { id: 18, title: "Prathiba Award Winners 5", category: "achievements", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.56.15 PM.jpeg" },

      { id: 19, title: "Prathiba Award Winners 6", category: "achievements", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.56.37 PM.jpeg" },

      { id: 20, title: "Prathiba Award Winners 7", category: "achievements", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.57.32 PM.jpeg" },

      { id: 21, title: "JEE Ranker 1", category: "achievements", image: "images/JEE Rankers/DSC_1080.JPG" },

      { id: 22, title: "JEE Ranker 2", category: "achievements", image: "images/JEE Rankers/DSC_1083.JPG" },

      { id: 23, title: "JEE Ranker 3", category: "achievements", image: "images/JEE Rankers/DSC_1086.JPG" },

      { id: 24, title: "JEE Ranker 4", category: "achievements", image: "images/JEE Rankers/DSC_1087.JPG" },

      { id: 25, title: "JEE Ranker 5", category: "achievements", image: "images/JEE Rankers/DSC_1091.JPG" }

    ],

    enquiries: [

      {

        id: 1,

        name: "Aarav Sharma",

        email: "aarav@example.com",

        phone: "9876543210",

        state: "Andhra Pradesh",

        currentClass: "Class VII",

        syllabus: "CBSE",

        campus: "Main Campus",

        programme: "Regular",

        message: "Enquiring about the syllabus and class availability for next year.",

        date: "2026-07-09T10:14:22.000Z"

      }

    ],

    achievements: [

      { id: 1, title: "SSC Results 2026 Toppers Board 1", category: "boards", image: "images/SSC Results 2026/9x6=1c (SSC-2026)_1(RV).jpg" },

      { id: 2, title: "SSC Results 2026 Toppers Board 2", category: "boards", image: "images/SSC Results 2026/9x6=1c (SSC-2026)_2.jpg" },

      { id: 3, title: "Prathiba Award Winners 1", category: "prathiba", image: "images/Prathiba award/DSC_6945.JPG" },

      { id: 4, title: "Prathiba Award Winners 2", category: "prathiba", image: "images/Prathiba award/DSC_6946.JPG" },

      { id: 5, title: "Prathiba Award Winners 3", category: "prathiba", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.55.16 PM.jpeg" },

      { id: 6, title: "Prathiba Award Winners 4", category: "prathiba", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.55.54 PM.jpeg" },

      { id: 7, title: "Prathiba Award Winners 5", category: "prathiba", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.56.15 PM.jpeg" },

      { id: 8, title: "Prathiba Award Winners 6", category: "prathiba", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.56.37 PM.jpeg" },

      { id: 9, title: "Prathiba Award Winners 7", category: "prathiba", image: "images/Prathiba award/WhatsApp Image 2025-06-09 at 2.57.32 PM.jpeg" },

      { id: 10, title: "JEE Ranker 1", category: "competitive", image: "images/JEE Rankers/DSC_1080.JPG" },

      { id: 11, title: "JEE Ranker 2", category: "competitive", image: "images/JEE Rankers/DSC_1083.JPG" },

      { id: 12, title: "JEE Ranker 3", category: "competitive", image: "images/JEE Rankers/DSC_1086.JPG" },

      { id: 13, title: "JEE Ranker 4", category: "competitive", image: "images/JEE Rankers/DSC_1087.JPG" },

      { id: 14, title: "JEE Ranker 5", category: "competitive", image: "images/JEE Rankers/DSC_1091.JPG" }

    ],

    facilities: [

      { id: 1, title: "Smart Classrooms", description: "Interactive screens, high-speed connectivity, and spacious seating arrangements.", image: "images/Literary Activities/Classrooms/DSC_1241.JPG" },

      { id: 2, title: "Science Labs", description: "Advanced practical sets for Physics, Chemistry, and Biology.", image: "images/Labs & Library/Science Lab/DSC_1147.JPG" },

      { id: 3, title: "Computer Labs", description: "Modern computing facilities to develop technical and programming skills.", image: "images/Labs & Library/Computer Lab/DSC_1275.JPG" },

      { id: 4, title: "Library", description: "Extensive collections of reference materials, encyclopedias, and literature books.", image: "images/Labs & Library/Library/DSC_1119.JPG" },

      { id: 5, title: "Sports Ground", description: "Professional play areas for football, volleyball, athletics, and indoor games.", image: "images/Sports and Games/DSCN1082.JPG" },

      { id: 6, title: "Transportation", description: "Safe and tracked school buses connecting surrounding areas.", image: "images/School Old Photos/MHS Office 1_20241212_164121_018.jpg" }

    ],

    events: [

      { id: 1, title: "Pongal & Rangoli Festival", image: "images/Pongal & Rangoli/DSC_652.jpeg" },

      { id: 2, title: "Republic Day", image: "images/Republic Day/DSC_6584.JPG" },

      { id: 3, title: "Prathiba Award Ceremony", image: "images/Prathiba award/DSC_6945.JPG" },

      { id: 4, title: "Charity Food Festival", image: "images/Social Service/Food Fest/DSC_3199.JPG" }

    ],

    pageSettings: {

      aboutBanner: "images/Graduation day/DSC_0285.JPG",

      aboutMain: "images/School Old Photos/MHS Office 1_20241212_164121_018.jpg",

      aboutEmblem: "images/logo.jpg",

      academicsBanner: "images/Academic Activities/Assemblies/DSCN4074.JPG",

      academicsLibrary: "images/Labs & Library/Library/DSC_1119.JPG",

      academicsComputerLab: "images/Labs & Library/Computer Lab/DSC_1275.JPG",

      academicsScienceLab: "images/Labs & Library/Science Lab/DSC_1147.JPG",

      academicsPreprimary: "images/Sports and Games/KG Playing Equipment/DSC_8538.JPG",

      academicsPrimary: "images/Literary Activities/Classrooms/DSC_1139.JPG",

      academicsMiddle: "images/Literary Activities/Classrooms/DSC_1241.JPG",

      academicsSecondary: "images/Literary Activities/Study Hours/DSC_8528.JPG",

      academicsExcellence: "images/Literary Activities/Classrooms/DSC_1241.JPG",

      academicsDigital: "images/Literary Activities/Classrooms/DSC_1241.JPG",

      academicsMaths: "images/Literary Activities/Classrooms/DSC_1228.JPG",

      academicsLanguage: "images/Literary Activities/Classrooms/DSC_1245.JPG",

      clubsMain: "images/Montfort B-day/DSC_7211.JPG",

      clubsArts: "images/Pongal & Rangoli/DSC_6556.jpeg",

      clubsSocial: "images/Social Service/Distributing Groceries to PH/DSC_3439.JPG",

      clubsScience: "images/Prathiba award/DSC_6945.JPG",

      clubsSports: "images/Sports Day/DSC_4794.JPG",

      clubsBanner: "images/Sports Day/DSC_4794.JPG",

      achievementsBanner: "images/Prathiba award/DSC_6945.JPG",

      galleryBanner: "images/Sports Day/DSC_4794.JPG",

      contactBanner: "images/Sports Day/DSC_4794.JPG",

      contactSatellite: "images/Photos/School Satillite Picture.jpg",

      emblemImage: "images/logo.jpg"

    }

  };



  // Load from LocalStorage or initialize with defaultDb

  function getDb() {

    try {

      const stored = localStorage.getItem(STORE_KEY);

      if (stored) {

        let parsed = JSON.parse(stored);

        

        let changed = false;



        // Recursive helper to clean legacy paths in-place

        function cleanLegacyPaths(obj) {

          if (typeof obj === 'string') {

            const cleanPattern = /images[/\\]00[1-3] Photos[/\\]/gi;

            if (cleanPattern.test(obj)) {

              obj = obj.replace(cleanPattern, 'images/');

              changed = true;

            }

            if (obj.includes('\\')) {

              obj = obj.replace(/\\/g, '/');

              changed = true;

            }

            return obj;

          } else if (Array.isArray(obj)) {

            return obj.map(item => cleanLegacyPaths(item));

          } else if (obj !== null && typeof obj === 'object') {

            for (let key in obj) {

              obj[key] = cleanLegacyPaths(obj[key]);

            }

            return obj;

          }

          return obj;

        }



        parsed = cleanLegacyPaths(parsed);



        // Self-healing: Ensure every top-level key and sub-key from defaultDb is present

        for (let key in defaultDb) {

          if (parsed[key] === undefined || parsed[key] === null) {

            parsed[key] = defaultDb[key];

            changed = true;

          } else if (typeof defaultDb[key] === 'object' && defaultDb[key] !== null && !Array.isArray(defaultDb[key])) {

            for (let subKey in defaultDb[key]) {

              if (parsed[key][subKey] === undefined || parsed[key][subKey] === null) {

                parsed[key][subKey] = defaultDb[key][subKey];

                changed = true;

              }

            }

          }

        }



        // Clean up unsplash placeholders inside hero and principalDesk dynamically

        if (parsed.hero && parsed.hero.backgroundImage && parsed.hero.backgroundImage.includes('unsplash.com')) {

          parsed.hero.backgroundImage = defaultDb.hero.backgroundImage;

          changed = true;

        }

        if (parsed.principalDesk && parsed.principalDesk.image && parsed.principalDesk.image.includes('unsplash.com')) {

          parsed.principalDesk.image = "images/principal.jpg";

          changed = true;

        }

        if (parsed.pageSettings) {

          if (parsed.pageSettings.emblemImage && parsed.pageSettings.emblemImage.includes('School Emblem/School Emblem.jpg')) {

            parsed.pageSettings.emblemImage = "images/logo.jpg";

            changed = true;

          }

          if (parsed.pageSettings.aboutEmblem && parsed.pageSettings.aboutEmblem.includes('School Emblem/School Emblem.jpg')) {

            parsed.pageSettings.aboutEmblem = "images/logo.jpg";

            changed = true;

          }

        }



        // In-place legacy gallery categories remapping

        if (parsed.gallery) {

          parsed.gallery.forEach(item => {

            if (item.category === 'campus') {

              item.category = 'celebrations';

              changed = true;

            } else if (item.category === 'academics') {

              item.category = 'achievements';

              changed = true;

            } else if (item.category === 'facilities') {

              item.category = 'sports';

              changed = true;

            } else if (item.category === 'events') {

              item.category = 'celebrations';

              changed = true;

            }

          });

        }



        if (changed) {

          saveDb(parsed);

        }

        return parsed;

      }

    } catch (e) {

      console.error('Error loading school database:', e);

    }

    // Save defaults to storage if empty

    saveDb(defaultDb);

    return defaultDb;

  }



  function saveDb(db) {

    try {

      localStorage.setItem(STORE_KEY, JSON.stringify(db));

    } catch (e) {

      console.error('Error writing to school database:', e);

      alert('Local Storage Quota Exceeded! The image you uploaded is too large, or you have reached the browser limit. Please try using a smaller/compressed file or deleting some existing items.');

    }

  }



  // Exposed API

  window.SchoolStore = {

    getHero: function () {

      return getDb().hero;

    },

    updateHero: function (heroData) {

      const db = getDb();

      db.hero = { ...db.hero, ...heroData };

      saveDb(db);

    },

    getTheme: function () {

      return getDb().theme;

    },

    updateTheme: function (themeData) {

      const db = getDb();

      db.theme = { ...db.theme, ...themeData };

      saveDb(db);

    },

    getPrincipalDesk: function () {

      return getDb().principalDesk;

    },

    updatePrincipalDesk: function (principalData) {

      const db = getDb();

      db.principalDesk = { ...db.principalDesk, ...principalData };

      saveDb(db);

    },

    getNews: function () {

      return getDb().news;

    },

    addNews: function (title, badge, link) {

      const db = getDb();

      const newId = db.news.length > 0 ? Math.max(...db.news.map(n => n.id)) + 1 : 1;

      const today = new Date().toISOString().split('T')[0];

      db.news.unshift({ id: newId, title, badge, date: today, link: link || "" });

      saveDb(db);

      return db.news;

    },

    updateNews: function (id, title, badge, link) {

      const db = getDb();

      const index = db.news.findIndex(n => n.id === parseInt(id));

      if (index !== -1) {

        db.news[index] = {

          ...db.news[index],

          title: title,

          badge: badge,

          link: link || ""

        };

        saveDb(db);

      }

      return db.news;

    },

    deleteNews: function (id) {

      const db = getDb();

      db.news = db.news.filter(item => item.id !== parseInt(id));

      saveDb(db);

      return db.news;

    },

    getGallery: function () {

      return getDb().gallery;

    },

    addGalleryImage: function (title, category, imageDataUrl) {

      const db = getDb();

      const newId = db.gallery.length > 0 ? Math.max(...db.gallery.map(g => g.id)) + 1 : 1;

      db.gallery.unshift({ id: newId, title, category, image: imageDataUrl });

      saveDb(db);

      return db.gallery;

    },

    deleteGalleryImage: function (id) {

      const db = getDb();

      db.gallery = db.gallery.filter(item => item.id !== parseInt(id));

      saveDb(db);

      return db.gallery;

    },

    updateGalleryImage: function (id, title, category, imageDataUrl) {

      const db = getDb();

      const index = db.gallery.findIndex(g => g.id === parseInt(id));

      if (index !== -1) {

        db.gallery[index] = {

          ...db.gallery[index],

          title: title,

          category: category,

          image: imageDataUrl || db.gallery[index].image

        };

        saveDb(db);

      }

      return db.gallery;

    },

    getEnquiries: function () {

      return getDb().enquiries;

    },

    addEnquiry: function (enquiryData) {

      const db = getDb();

      const newId = db.enquiries.length > 0 ? Math.max(...db.enquiries.map(e => e.id)) + 1 : 1;

      const newEnquiry = {

        id: newId,

        ...enquiryData,

        date: new Date().toISOString()

      };

      db.enquiries.unshift(newEnquiry);

      saveDb(db);

      return newEnquiry;

    },

    deleteEnquiry: function (id) {

      const db = getDb();

      db.enquiries = db.enquiries.filter(e => e.id !== parseInt(id));

      saveDb(db);

      return db.enquiries;

    },

    getAchievements: function () {

      return getDb().achievements;

    },

    addAchievement: function (title, category, imageDataUrl) {

      const db = getDb();

      const newId = db.achievements.length > 0 ? Math.max(...db.achievements.map(a => a.id)) + 1 : 1;

      db.achievements.unshift({ id: newId, title, category, image: imageDataUrl });

      saveDb(db);

      return db.achievements;

    },

    deleteAchievement: function (id) {

      const db = getDb();

      db.achievements = db.achievements.filter(a => a.id !== parseInt(id));

      saveDb(db);

      return db.achievements;

    },

    updateAchievement: function (id, title, category, imageDataUrl) {

      const db = getDb();

      const index = db.achievements.findIndex(a => a.id === parseInt(id));

      if (index !== -1) {

        db.achievements[index] = {

          ...db.achievements[index],

          title: title,

          category: category,

          image: imageDataUrl || db.achievements[index].image

        };

        saveDb(db);

      }

      return db.achievements;

    },

    getFacilities: function () {

      return getDb().facilities || [];

    },

    addFacility: function (title, description, imageDataUrl) {

      const db = getDb();

      if (!db.facilities) db.facilities = [];

      const newId = db.facilities.length > 0 ? Math.max(...db.facilities.map(f => f.id)) + 1 : 1;

      db.facilities.push({ id: newId, title, description, image: imageDataUrl });

      saveDb(db);

      return db.facilities;

    },

    deleteFacility: function (id) {

      const db = getDb();

      if (!db.facilities) db.facilities = [];

      db.facilities = db.facilities.filter(item => item.id !== parseInt(id));

      saveDb(db);

      return db.facilities;

    },

    updateFacility: function (id, title, description, imageDataUrl) {

      const db = getDb();

      if (!db.facilities) db.facilities = [];

      const index = db.facilities.findIndex(f => f.id === parseInt(id));

      if (index !== -1) {

        db.facilities[index] = {

          ...db.facilities[index],

          title: title,

          description: description,

          image: imageDataUrl || db.facilities[index].image

        };

        saveDb(db);

      }

      return db.facilities;

    },

    getEvents: function () {

      return getDb().events || [];

    },

    addEvent: function (title, imageDataUrl) {

      const db = getDb();

      if (!db.events) db.events = [];

      const newId = db.events.length > 0 ? Math.max(...db.events.map(e => e.id)) + 1 : 1;

      db.events.unshift({ id: newId, title, image: imageDataUrl });

      saveDb(db);

      return db.events;

    },

    deleteEvent: function (id) {

      const db = getDb();

      if (!db.events) db.events = [];

      db.events = db.events.filter(item => item.id !== parseInt(id));

      saveDb(db);

      return db.events;

    },

    updateEvent: function (id, title, imageDataUrl) {

      const db = getDb();

      if (!db.events) db.events = [];

      const index = db.events.findIndex(e => e.id === parseInt(id));

      if (index !== -1) {

        db.events[index] = {

          ...db.events[index],

          title: title,

          image: imageDataUrl || db.events[index].image

        };

        saveDb(db);

      }

      return db.events;

    },

    getPageSettings: function () {

      return getDb().pageSettings || {};

    },

    updatePageSetting: function (key, value) {

      const db = getDb();

      if (!db.pageSettings) db.pageSettings = { ...defaultDb.pageSettings };

      db.pageSettings[key] = value;

      saveDb(db);

      return db.pageSettings;

    },

    importDb: function (jsonString) {

      try {

        const imported = JSON.parse(jsonString);

        // Simple validation

        if (imported && imported.hero && imported.gallery) {

          saveDb(imported);

          return true;

        }

      } catch (e) {

        console.error('Error importing database:', e);

      }

      return false;

    },

    getRawDbString: function () {

      return JSON.stringify(getDb(), null, 2);

    },

    resetToDefaults: function () {

      saveDb(defaultDb);

      return defaultDb;

    }

  };

})();

