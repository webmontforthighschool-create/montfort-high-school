/**
 * Montfort High School - Main Interactivity Script
 */

document.addEventListener('DOMContentLoaded', function () {
  // --- 1. Sticky Header Shadow ---
  const header = document.querySelector('.main-header');
  if (header) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 20) {
        header.classList.add('scroll-shadow');
      } else {
        header.classList.remove('scroll-shadow');
      }
    });
  }

  // --- 2. Mobile Nav Menu Toggle ---
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', function () {
      menuToggle.classList.toggle('active');
      navLinks.classList.toggle('active');
    });
  }

  // Close nav on click outer or on link click
  document.addEventListener('click', function (e) {
    if (navLinks && navLinks.classList.contains('active')) {
      if (!navLinks.contains(e.target) && !menuToggle.contains(e.target)) {
        menuToggle.classList.remove('active');
        navLinks.classList.remove('active');
      }
    }
  });

  // --- 3. Testimonial Slider (Home Page) ---
  const testimonials = [
    {
      text: "Montfort High School has helped my child grow academically and personally. The focus on values alongside education is what makes this school truly exceptional.",
      author: "Parent Name",
      meta: "Parent of Class VIII Student",
      initials: "PN"
    },
    {
      text: "The dedication of the teachers at Montfort is outstanding. The individual attention and continuous guidance have boosted my daughter's academic performance and confidence.",
      author: "M. Rajesh Kumar",
      meta: "Parent of Class X Student",
      initials: "RK"
    },
    {
      text: "With world-class facilities and focus on sports & co-curricular activities, Montfort provides a holistic development environment that is hard to find elsewhere.",
      author: "Sujatha Reddy",
      meta: "Parent of Class V Student",
      initials: "SR"
    }
  ];

  const testimonialText = document.getElementById('testimonial-text');
  const testimonialAuthor = document.getElementById('testimonial-author');
  const testimonialMeta = document.getElementById('testimonial-meta');
  const testimonialInitials = document.getElementById('testimonial-initials');
  const dotsContainer = document.getElementById('testimonial-dots');

  if (testimonialText && dotsContainer) {
    let currentTestimonial = 0;

    // Create dots
    dotsContainer.innerHTML = '';
    testimonials.forEach((_, index) => {
      const dot = document.createElement('div');
      dot.className = `dot ${index === 0 ? 'active' : ''}`;
      dot.addEventListener('click', () => {
        showTestimonial(index);
      });
      dotsContainer.appendChild(dot);
    });

    function showTestimonial(index) {
      currentTestimonial = index;
      const t = testimonials[index];
      
      testimonialText.style.opacity = 0;
      setTimeout(() => {
        testimonialText.textContent = `"${t.text}"`;
        testimonialAuthor.textContent = t.author;
        testimonialMeta.textContent = t.meta;
        testimonialInitials.textContent = t.initials;
        testimonialText.style.opacity = 1;
      }, 200);

      // Update dots
      const dots = dotsContainer.querySelectorAll('.dot');
      dots.forEach((dot, dIdx) => {
        if (dIdx === index) {
          dot.classList.add('active');
        } else {
          dot.classList.remove('active');
        }
      });
    }

    // Auto rotate every 6s
    setInterval(() => {
      let nextIndex = (currentTestimonial + 1) % testimonials.length;
      showTestimonial(nextIndex);
    }, 6000);
  }

  // --- 4. FAQ Accordion ---
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', function () {
        const isActive = item.classList.contains('active');
        // Close all first
        faqItems.forEach(i => i.classList.remove('active'));
        // Toggle current
        if (!isActive) {
          item.classList.add('active');
        }
      });
    }
  });

  // --- 5. Dynamically populate elements from SchoolStore (localStorage) ---
  if (window.SchoolStore) {
    // 5.1 Hero content loading
    const heroSection = document.getElementById('dynamic-hero');
    const heroTitle = document.getElementById('hero-title');
    const heroSubtitle = document.getElementById('hero-subtitle');
    const heroTagline = document.getElementById('hero-tagline');
    const statEst = document.getElementById('stat-established');
    const statStudents = document.getElementById('stat-students');
    const statStaff = document.getElementById('stat-staff');
    const statExcellence = document.getElementById('stat-excellence');

    const hero = window.SchoolStore.getHero();
    if (hero) {
      if (heroSection) {
        const bgImages = hero.backgroundImages || [hero.backgroundImage];
        if (bgImages.length > 1) {
          let sliderDiv = heroSection.querySelector('.hero-slider');
          if (!sliderDiv) {
            sliderDiv = document.createElement('div');
            sliderDiv.className = 'hero-slider';
            sliderDiv.style.cssText = 'position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; pointer-events: none;';
            
            bgImages.forEach((imgUrl, index) => {
              const slide = document.createElement('div');
              slide.className = `hero-slide ${index === 0 ? 'active' : ''}`;
              slide.style.cssText = `position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: url('${imgUrl}'); background-size: cover; background-position: center; opacity: ${index === 0 ? '1' : '0'}; transition: opacity 1.5s ease-in-out;`;
              sliderDiv.appendChild(slide);
            });
            
            heroSection.appendChild(sliderDiv);
            
            let currentSlideIndex = 0;
            const slides = sliderDiv.querySelectorAll('.hero-slide');
            setInterval(() => {
              slides[currentSlideIndex].classList.remove('active');
              slides[currentSlideIndex].style.opacity = '0';
              currentSlideIndex = (currentSlideIndex + 1) % slides.length;
              slides[currentSlideIndex].classList.add('active');
              slides[currentSlideIndex].style.opacity = '1';
            }, 5000);
          }
        } else {
          heroSection.style.backgroundImage = `url('${hero.backgroundImage}')`;
        }
      }
      if (heroTitle) heroTitle.textContent = hero.title;
      if (heroSubtitle) heroSubtitle.textContent = hero.subtitle;
      if (heroTagline) heroTagline.textContent = hero.tagline;
      if (statEst) statEst.textContent = hero.stats.established;
      if (statStudents) statStudents.textContent = hero.stats.students;
      if (statStaff) statStaff.textContent = hero.stats.staff;
      if (statExcellence) statExcellence.textContent = hero.stats.excellence;
    }

    // 5.2 Theme banner loading
    const themeKeyword = document.getElementById('theme-keyword');
    const themeDesc = document.getElementById('theme-description');
    const theme = window.SchoolStore.getTheme();
    if (theme) {
      if (themeKeyword) themeKeyword.textContent = theme.keyword;
      if (themeDesc) themeDesc.textContent = theme.description;
    }

    // 5.3 Principal's Desk loading
    const principalName = document.getElementById('principal-name');
    const principalNameDesk = document.getElementById('principal-name-desk');
    const principalImage = document.getElementById('principal-image');
    const principalText = document.getElementById('principal-text');
    const principalMsg = document.getElementById('principal-message');

    const principal = window.SchoolStore.getPrincipalDesk();
    if (principal) {
      if (principalName) principalName.textContent = principal.fullName;
      if (principalNameDesk) principalNameDesk.textContent = principal.fullName;
      if (principalText) principalText.textContent = principal.text;
      if (principalMsg) principalMsg.textContent = `"${principal.message}"`;
      if (principalImage) principalImage.src = principal.image;
      
      // Also update any elements with dynamic principal classes
      const dynamicPrincipalImgs = document.querySelectorAll('.dynamic-principal-img');
      dynamicPrincipalImgs.forEach(img => img.src = principal.image);
      const dynamicPrincipalNames = document.querySelectorAll('.dynamic-principal-name');
      dynamicPrincipalNames.forEach(el => el.textContent = principal.fullName);
    }

    // 5.4 News List dynamic population
    const newsListContainer = document.getElementById('dynamic-news-list');
    if (newsListContainer) {
      const newsItems = window.SchoolStore.getNews();
      newsListContainer.innerHTML = '';
      if (newsItems && newsItems.length > 0) {
        newsItems.forEach(item => {
          const li = document.createElement('li');
          li.className = `news-item ${item.badge ? 'new' : ''}`;
          
          const targetLink = item.link || 'academics.html';
          li.innerHTML = `
            <a href="${targetLink}" class="news-item-link" style="display: block; width: 100%; text-decoration: none; color: inherit;" ${item.link ? 'target="_blank"' : ''}>
              <div class="news-details">
                <span class="news-dot"></span>
                <span class="news-title" style="font-weight: 500;">${item.title}</span>
                ${item.badge ? `<span class="news-badge">${item.badge}</span>` : ''}
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; padding-left: 20px;">
                <span class="news-date" style="font-size: 0.75rem; color: var(--text-light);">${item.date}</span>
                <span class="news-click-here" style="font-size: 0.75rem; color: var(--accent-gold); font-weight: 600;">Click here ➔</span>
              </div>
            </a>
          `;
          newsListContainer.appendChild(li);
        });
      } else {
        newsListContainer.innerHTML = '<li class="news-item"><span class="news-title">No announcements at this time.</span></li>';
      }
    }

    // 5.4.1 Facilities Dynamic Render (Home Page)
    const facilitiesGrid = document.getElementById('dynamic-facilities-grid');
    if (facilitiesGrid) {
      const facilities = window.SchoolStore.getFacilities();
      facilitiesGrid.innerHTML = '';
      facilities.forEach(f => {
        const div = document.createElement('div');
        div.className = 'facility-card';
        div.innerHTML = `
          <img src="${f.image}" alt="${f.title}">
          <div class="facility-overlay">
            <h4>${f.title}</h4>
            <p>${f.description}</p>
          </div>
        `;
        facilitiesGrid.appendChild(div);
      });
    }

    // 5.4.2 Recent Events Dynamic Render (Home Page)
    const eventsGrid = document.getElementById('dynamic-events-grid');
    if (eventsGrid) {
      const events = window.SchoolStore.getEvents();
      eventsGrid.innerHTML = '';
      events.forEach(e => {
        const div = document.createElement('div');
        div.className = 'event-card';
        div.innerHTML = `
          <div class="event-image">
            <img src="${e.image}" alt="${e.title}">
          </div>
          <div class="event-content">
            <h4>${e.title}</h4>
          </div>
        `;
        eventsGrid.appendChild(div);
      });
    }

    // 5.4.3 Page Banners & Static Images Render (All Pages)
    const pageSettings = window.SchoolStore.getPageSettings();
    if (pageSettings) {
      // Banners
      const aboutBanner = document.getElementById('about-banner');
      if (aboutBanner && pageSettings.aboutBanner) aboutBanner.style.backgroundImage = `url('${pageSettings.aboutBanner}')`;
      
      const academicsBanner = document.getElementById('academics-banner');
      if (academicsBanner && pageSettings.academicsBanner) academicsBanner.style.backgroundImage = `url('${pageSettings.academicsBanner}')`;
      
      const clubsBanner = document.getElementById('clubs-banner');
      if (clubsBanner && pageSettings.clubsBanner) clubsBanner.style.backgroundImage = `url('${pageSettings.clubsBanner}')`;
      
      const achievementsBanner = document.getElementById('achievements-banner');
      if (achievementsBanner && pageSettings.achievementsBanner) achievementsBanner.style.backgroundImage = `url('${pageSettings.achievementsBanner}')`;
      
      const galleryBanner = document.getElementById('gallery-banner');
      if (galleryBanner && pageSettings.galleryBanner) galleryBanner.style.backgroundImage = `url('${pageSettings.galleryBanner}')`;
      
      const contactBanner = document.getElementById('contact-banner');
      if (contactBanner && pageSettings.contactBanner) contactBanner.style.backgroundImage = `url('${pageSettings.contactBanner}')`;
      
      // Static Images
      const homeEmblemImg = document.getElementById('home-emblem-img');
      if (homeEmblemImg && pageSettings.emblemImage) homeEmblemImg.src = pageSettings.emblemImage;

      const aboutMainImg = document.getElementById('about-main-img');
      if (aboutMainImg && pageSettings.aboutMain) aboutMainImg.src = pageSettings.aboutMain;

      const aboutEmblemImg = document.getElementById('about-emblem-img');
      if (aboutEmblemImg && pageSettings.aboutEmblem) aboutEmblemImg.src = pageSettings.aboutEmblem;

      const academicsLibraryImg = document.getElementById('academics-library-img');
      if (academicsLibraryImg && pageSettings.academicsLibrary) academicsLibraryImg.src = pageSettings.academicsLibrary;

      const academicsComputerImg = document.getElementById('academics-computer-img');
      if (academicsComputerImg && pageSettings.academicsComputerLab) academicsComputerImg.src = pageSettings.academicsComputerLab;

      const academicsScienceImg = document.getElementById('academics-science-img');
      if (academicsScienceImg && pageSettings.academicsScienceLab) academicsScienceImg.src = pageSettings.academicsScienceLab;

      const academicsPreprimaryImg = document.getElementById('academics-preprimary-img');
      if (academicsPreprimaryImg && pageSettings.academicsPreprimary) academicsPreprimaryImg.src = pageSettings.academicsPreprimary;

      const academicsPrimaryImg = document.getElementById('academics-primary-img');
      if (academicsPrimaryImg && pageSettings.academicsPrimary) academicsPrimaryImg.src = pageSettings.academicsPrimary;

      const academicsMiddleImg = document.getElementById('academics-middle-img');
      if (academicsMiddleImg && pageSettings.academicsMiddle) academicsMiddleImg.src = pageSettings.academicsMiddle;

      const academicsSecondaryImg = document.getElementById('academics-secondary-img');
      if (academicsSecondaryImg && pageSettings.academicsSecondary) academicsSecondaryImg.src = pageSettings.academicsSecondary;

      const academicsExcellenceImg = document.getElementById('academics-excellence-img');
      if (academicsExcellenceImg && pageSettings.academicsExcellence) academicsExcellenceImg.src = pageSettings.academicsExcellence;

      const academicsDigitalImg = document.getElementById('academics-digital-img');
      if (academicsDigitalImg && pageSettings.academicsDigital) academicsDigitalImg.src = pageSettings.academicsDigital;

      const academicsMathsImg = document.getElementById('academics-maths-img');
      if (academicsMathsImg && pageSettings.academicsMaths) academicsMathsImg.src = pageSettings.academicsMaths;

      const academicsLanguageImg = document.getElementById('academics-language-img');
      if (academicsLanguageImg && pageSettings.academicsLanguage) academicsLanguageImg.src = pageSettings.academicsLanguage;

      const clubsMainImg = document.getElementById('clubs-main-img');
      if (clubsMainImg && pageSettings.clubsMain) clubsMainImg.src = pageSettings.clubsMain;

      const clubsArtsImg = document.getElementById('clubs-arts-img');
      if (clubsArtsImg && pageSettings.clubsArts) clubsArtsImg.src = pageSettings.clubsArts;

      const clubsSocialImg = document.getElementById('clubs-social-img');
      if (clubsSocialImg && pageSettings.clubsSocial) clubsSocialImg.src = pageSettings.clubsSocial;

      const clubsScienceImg = document.getElementById('clubs-science-img');
      if (clubsScienceImg && pageSettings.clubsScience) clubsScienceImg.src = pageSettings.clubsScience;

      const clubsSportsImg = document.getElementById('clubs-sports-img');
      if (clubsSportsImg && pageSettings.clubsSports) clubsSportsImg.src = pageSettings.clubsSports;
    }

    // 5.5 Admission Form Submission handler
    const admissionForm = document.getElementById('admission-enquiry-form');
    if (admissionForm) {
      admissionForm.addEventListener('submit', function (e) {
        e.preventDefault();
        
        const enquiryData = {
          name: document.getElementById('enq-name').value,
          email: document.getElementById('enq-email').value,
          phone: document.getElementById('enq-phone').value,
          state: document.getElementById('enq-state').value,
          currentClass: document.getElementById('enq-class').value,
          syllabus: document.getElementById('enq-syllabus').value,
          campus: document.getElementById('enq-campus').value,
          programme: document.getElementById('enq-programme').value,
          message: document.getElementById('enq-message').value
        };

        window.SchoolStore.addEnquiry(enquiryData);
        
        // Show success visual message
        alert('Thank you! Your enquiry has been submitted. Our admissions coordinator will contact you shortly.');
        admissionForm.reset();
      });
    }

    // 5.6 Contact Form handling (saves general inquiry as well)
    const contactForm = document.getElementById('contact-us-form');
    if (contactForm) {
      contactForm.addEventListener('submit', function (e) {
        e.preventDefault();
        
        const contactData = {
          name: document.getElementById('c-name').value,
          email: document.getElementById('c-email').value,
          phone: document.getElementById('c-phone').value,
          state: 'General Contact',
          currentClass: 'N/A',
          syllabus: 'N/A',
          campus: 'N/A',
          programme: 'N/A',
          message: document.getElementById('c-message').value
        };

        window.SchoolStore.addEnquiry(contactData);
        alert('Thank you for contacting us! Your message has been sent successfully.');
        contactForm.reset();
      });
    }

    // 5.7 Gallery population (Gallery Page)
    const galleryGrid = document.getElementById('dynamic-gallery-grid');
    const filterButtons = document.querySelectorAll('.filter-btn');

    if (galleryGrid) {
      const photos = window.SchoolStore.getGallery();
      
      function renderGallery(filterCategory = 'all') {
        galleryGrid.innerHTML = '';
        const filteredPhotos = filterCategory === 'all' 
          ? photos 
          : photos.filter(p => p.category.toLowerCase() === filterCategory.toLowerCase());

        if (filteredPhotos.length === 0) {
          galleryGrid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-light);">No images found in this category.</div>';
          return;
        }

        filteredPhotos.forEach(photo => {
          const item = document.createElement('div');
          item.className = 'gallery-item';
          item.innerHTML = `
            <img src="${photo.image}" alt="${photo.title}" loading="lazy">
            <div class="gallery-item-info">
              <h4>${photo.title}</h4>
              <p style="text-transform: capitalize;">${photo.category.replace('_', ' ')}</p>
            </div>
          `;
          galleryGrid.appendChild(item);
        });
      }

      // Initial Render
      renderGallery('all');

      // Set up click events on filter buttons
      filterButtons.forEach(btn => {
        btn.addEventListener('click', function () {
          filterButtons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const category = btn.getAttribute('data-filter');
          renderGallery(category);
        });
      });
    }

    // 5.8 Achievements Dynamic Population
    const boardsContainer = document.getElementById('boards-images-container');
    const prathibaContainer = document.getElementById('prathiba-images-container');
    const competitiveContainer = document.getElementById('competitive-images-container');

    if (boardsContainer || prathibaContainer || competitiveContainer) {
      const achievements = window.SchoolStore.getAchievements();
      
      if (boardsContainer) {
        boardsContainer.innerHTML = '';
        const boards = achievements.filter(a => a.category === 'boards');
        boards.forEach(item => {
          const div = document.createElement('div');
          div.style.cssText = 'box-shadow: var(--shadow-lg); border-radius: 8px; overflow: hidden; border: 1px solid #e2e8f0; background-color: #fff;';
          div.innerHTML = `
            <img src="${item.image}" alt="${item.title}" style="width: 100%; height: auto; display: block; transition: transform 0.3s ease;" class="hover-zoom">
          `;
          boardsContainer.appendChild(div);
        });
      }
      
      if (prathibaContainer) {
        prathibaContainer.innerHTML = '';
        const prathiba = achievements.filter(a => a.category === 'prathiba');
        prathiba.forEach(item => {
          const div = document.createElement('div');
          div.className = 'achievement-card';
          div.innerHTML = `
            <img src="${item.image}" alt="${item.title}" class="hover-zoom">
          `;
          prathibaContainer.appendChild(div);
        });
      }
      
      if (competitiveContainer) {
        competitiveContainer.innerHTML = '';
        const competitive = achievements.filter(a => a.category === 'competitive');
        competitive.forEach(item => {
          const div = document.createElement('div');
          div.className = 'achievement-card';
          div.innerHTML = `
            <img src="${item.image}" alt="${item.title}" class="hover-zoom">
          `;
          competitiveContainer.appendChild(div);
        });
      }
    }
  }

  // --- 6. Smooth timeline items fade-in effect on scroll ---
  const timelineItems = document.querySelectorAll('.timeline-item');
  if (timelineItems.length > 0) {
    const observerOptions = {
      root: null,
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const timelineObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    timelineItems.forEach(item => {
      item.style.opacity = 0;
      item.style.transform = 'translateY(30px)';
      item.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
      timelineObserver.observe(item);
    });
  }

  // --- 7. Dynamic Image Lightbox (Zoom Pop-up) for Gallery & Achievements ---
  function initLightbox() {
    let lightbox = document.getElementById('lightbox-modal');
    if (!lightbox) {
      lightbox = document.createElement('div');
      lightbox.id = 'lightbox-modal';
      lightbox.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(11, 21, 35, 0.95);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.3s ease;
      `;
      
      lightbox.innerHTML = `
        <button id="lightbox-close" style="
          position: absolute;
          top: 20px;
          right: 30px;
          background: none;
          border: none;
          color: #fff;
          font-size: 3rem;
          cursor: pointer;
          z-index: 100000;
          transition: transform 0.2s ease;
        ">&times;</button>
        <img id="lightbox-img" src="" alt="Enlarged View" style="
          max-width: 90%;
          max-height: 85%;
          object-fit: contain;
          box-shadow: 0 10px 30px rgba(0,0,0,0.6);
          border-radius: 6px;
          transform: scale(0.9);
          transition: transform 0.3s ease;
        ">
      `;
      document.body.appendChild(lightbox);
      
      const closeBtn = lightbox.querySelector('#lightbox-close');
      const lightboxImg = lightbox.querySelector('#lightbox-img');
      
      function closeLightbox() {
        lightbox.style.opacity = '0';
        lightbox.style.pointerEvents = 'none';
        lightboxImg.style.transform = 'scale(0.9)';
      }
      
      closeBtn.addEventListener('click', closeLightbox);
      lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
          closeLightbox();
        }
      });
      
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          closeLightbox();
        }
      });
    }
    return lightbox;
  }

  function setupLightboxListeners() {
    const lightbox = initLightbox();
    const lightboxImg = lightbox.querySelector('#lightbox-img');
    
    // Delegate click events on images in gallery-grid or achievement-card
    document.addEventListener('click', function(e) {
      const targetImg = e.target.closest('.gallery-item img, .gallery-card img, .achievement-card img, .masonry-item img, #boards-images-container img, .facility-card img, .program-img img');
      if (targetImg) {
        e.preventDefault();
        lightboxImg.src = targetImg.src;
        lightbox.style.opacity = '1';
        lightbox.style.pointerEvents = 'auto';
        setTimeout(() => {
          lightboxImg.style.transform = 'scale(1)';
        }, 50);
      }
    });

    // Hover effect styles injection
    const style = document.createElement('style');
    style.innerHTML = `
      .gallery-item img, .gallery-card img, .achievement-card img, .masonry-item img, #boards-images-container img, .facility-card img {
        cursor: pointer;
        transition: transform 0.3s ease;
      }
      .gallery-item img:hover, .gallery-card img:hover, .achievement-card img:hover, .masonry-item img:hover, #boards-images-container img:hover, .facility-card img:hover {
        transform: scale(1.03);
      }
    `;
    document.head.appendChild(style);
  }

  setupLightboxListeners();
});
